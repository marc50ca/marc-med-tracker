---
name: Bug Report
about: Report a bug or issue with Marc Med Tracker
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description
<!-- A clear and concise description of what the bug is -->

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. See error

## Expected Behavior
<!-- What you expected to happen -->

## Actual Behavior
<!-- What actually happened -->

## Environment
- **Home Assistant Version**: <!-- e.g., 2025.2.1 -->
- **Marc Med Tracker Version**: <!-- e.g., 2.0.0 -->
- **Installation Method**: <!-- YAML / Config Flow -->
- **Browser** (if relevant): <!-- e.g., Chrome 120 -->

## Configuration
<!-- Paste relevant configuration (remove sensitive info) -->
```yaml
marc_med_tracker:
  medications:
    - name: "..."
```

## Logs
<!-- Paste relevant log entries -->
```
Settings → System → Logs
Filter: marc_med_tracker
```

## Screenshots
<!-- If applicable, add screenshots -->

## Additional Context
<!-- Any other context about the problem -->
